import React from "react";

export default function BubbleBIcon({ size = 64, ...props }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 240 280"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Bubble AI B icon"
      {...props}
    >
      <rect x="66" y="40" width="24" height="170" rx="12" ry="12" fill="#FFD24D" />
      <circle cx="130" cy="80" r="40" fill="#9A4DFF" />
      <rect x="90" y="120" width="100" height="90" rx="25" ry="25" fill="#2363FF" />
    </svg>
  );
}
